/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import Model.Sach;
import java.util.List;
import untility.DBConText;

/**
 *
 * @author admin
 */
public class SachService {

    public ArrayList<Sach> getAllData() {
        ArrayList<Sach> list = new ArrayList<>();
        list.clear();
        String sql = "SELECT MaSach, TenSach, TrangThai FROM Sach";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString("MaSach"));
                sach.setTenSach(rs.getString("TenSach"));
                sach.setTrangThai(rs.getBoolean("TrangThai"));
                list.add(sach);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insertData(Sach sach) {
        String sql = "INSERT INTO NhaXuatBan (TenNhaXuatBan)\n"
                + "VALUES ('Publisher A')\n"
                + "INSERT INTO Sach (MaSach,MaNhaXuatBan, TenSach, TrangThai) \n"
                + "                     VALUES (?,SCOPE_IDENTITY(),?,?)";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setObject(1, sach.getMaSach());
            pstm.setObject(2, sach.getTenSach());
            pstm.setObject(3, sach.isTrangThai());
            return pstm.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteData(Sach sach) {
        String sql = "DELETE FROM Sach WHERE MaSach=?\n"
                + "Delete from NhaXuatBan where MaNhaXuatBan =?";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setObject(1, sach.getMaSach());
            pstm.setObject(2, sach.getMaNhaXuatBan());
            return pstm.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Integer update(Sach sach) {
        Integer row = null;
        String sql = "UPDATE Sach SET\n"
                + "TenSach = ?,\n"
                + "TrangThai = ?\n"
                + "WHERE MaSach = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setObject(3, sach.getMaSach());
            pstm.setObject(1, sach.getTenSach());
            pstm.setObject(2, sach.isTrangThai());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }

    public List<Sach> getSachByMaSach(String maSach) {
        List<Sach> s=new ArrayList<>();
        String sql = "SELECT MaSach, TenSach from Sach WHERE MaSach like '%"+maSach+"%'";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                Sach sach = new Sach();
                sach.setMaSach(rs.getString("MaSach"));
                sach.setTenSach(rs.getString("TenSach"));
                s.add(sach);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return s;
    }
    public List<String> selectMaNXB() {
        List<String> data = new ArrayList<>();
        String sql = "SELECT MaNhaXuatBan FROM NhaXuatBan";

        try (Connection con = DBConText.getConnection(); PreparedStatement pstm = con.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {

                String value = rs.getString("MaNhaXuatBan");
                data.add(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

}
