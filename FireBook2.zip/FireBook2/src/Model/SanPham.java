/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author admin
 */
public class SanPham {
    Sach_1 sach;
    TacGia tacGia;
    TheLoai theLoai;
    SachCT sachCT;
    NXB nhaXuatBan;

    public SanPham() {
    }

    public SanPham(Sach_1 sach, TacGia tacGia, TheLoai theLoai, SachCT sachCT, NXB nhaXuatBan) {
        this.sach = new Sach_1();
        this.tacGia = new TacGia();
        this.theLoai = new TheLoai();
        this.sachCT = new SachCT();
        this.nhaXuatBan = new NXB();
    }

    public Sach_1 getSach() {
        return sach;
    }

    public void setSach(Sach_1 sach) {
        this.sach = sach;
    }

    public TacGia getTacGia() {
        return tacGia;
    }

    public void setTacGia(TacGia tacGia) {
        this.tacGia = tacGia;
    }

    public TheLoai getTheLoai() {
        return theLoai;
    }

    public void setTheLoai(TheLoai theLoai) {
        this.theLoai = theLoai;
    }

    public SachCT getSachCT() {
        return sachCT;
    }

    public void setSachCT(SachCT sachCT) {
        this.sachCT = sachCT;
    }

    public NXB getNhaXuatBan() {
        return nhaXuatBan;
    }

    public void setNhaXuatBan(NXB nhaXuatBan) {
        this.nhaXuatBan = nhaXuatBan;
    }

    @Override
    public String toString() {
        return sach + "," + tacGia + "," + theLoai + "," + sachCT + "," + nhaXuatBan;
    }
    
    
}
