/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author admin
 */
public class SachCT {
    String maSachCT;
    String maTheLoai;
    String maSach;
    String maTacGia;
    

    public SachCT() {
    }

    public SachCT(String maSachCT, String maTheLoai, String maSach, String maTacGia) {
        this.maSachCT = maSachCT;
        this.maTheLoai = maTheLoai;
        this.maSach = maSach;
        this.maTacGia = maTacGia;
    }

    public String getMaSachCT() {
        return maSachCT;
    }

    public void setMaSachCT(String maSachCT) {
        this.maSachCT = maSachCT;
    }

    public String getMaTheLoai() {
        return maTheLoai;
    }

    public void setMaTheLoai(String maTheLoai) {
        this.maTheLoai = maTheLoai;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getMaTacGia() {
        return maTacGia;
    }

    public void setMaTacGia(String maTacGia) {
        this.maTacGia = maTacGia;
    }

   

    @Override
    public String toString() {
        return maSachCT + "," + maTheLoai + "," + maSach + "," + maTacGia;
    }
    
    
}
