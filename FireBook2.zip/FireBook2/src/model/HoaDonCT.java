/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author admin
 */
public class HoaDonCT {
    String maHoaDonCT;
    String MaSachCT;
    String MahoaDon;
    int soLuong;
    double giaBan;

    public HoaDonCT() {
    }

    public HoaDonCT(String maHoaDonCT, String MaSachCT, String MahoaDon, int soLuong, double giaBan) {
        this.maHoaDonCT = maHoaDonCT;
        this.MaSachCT = MaSachCT;
        this.MahoaDon = MahoaDon;
        this.soLuong = soLuong;
        this.giaBan = giaBan;
    }

    public String getMaHoaDonCT() {
        return maHoaDonCT;
    }

    public void setMaHoaDonCT(String maHoaDonCT) {
        this.maHoaDonCT = maHoaDonCT;
    }

    public String getMaSachCT() {
        return MaSachCT;
    }

    public void setMaSachCT(String MaSachCT) {
        this.MaSachCT = MaSachCT;
    }

    public String getMahoaDon() {
        return MahoaDon;
    }

    public void setMahoaDon(String MahoaDon) {
        this.MahoaDon = MahoaDon;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    @Override
    public String toString() {
        return maHoaDonCT + "," + MaSachCT + "," + MahoaDon + "," + soLuong + "," + giaBan;
    }

    
    
}
