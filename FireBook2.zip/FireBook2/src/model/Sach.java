/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author admin
 */
public class Sach {
    String maSach;
    String maNXB;
    String tenSach;
    double giaBan;
    String moTa;
    int soLuong;
    boolean trangThai;

    public Sach() {
    }

    public Sach(String maSach, String maNXB, String tenSach, double giaBan, String moTa, int soLuong, boolean trangThai) {
        this.maSach = maSach;
        this.maNXB = maNXB;
        this.tenSach = tenSach;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.soLuong = soLuong;
        this.trangThai = trangThai;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getMaNXB() {
        return maNXB;
    }

    public void setMaNXB(String maNXB) {
        this.maNXB = maNXB;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return maSach + "," + maNXB + "," + tenSach + "," + giaBan + ", moTa=" + moTa + "," + soLuong + "," + trangThai;
    }
    
    
}
