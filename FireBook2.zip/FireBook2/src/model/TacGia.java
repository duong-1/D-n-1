/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author admin
 */
public class TacGia {
    String maTG;
    String hoTen;
    String date;
    String queQuan;
    boolean trangThai;

    public TacGia(String maTG, String hoTen, String date, String queQuan, boolean trangThai) {
        this.maTG = maTG;
        this.hoTen = hoTen;
        this.date = date;
        this.queQuan = queQuan;
        this.trangThai = trangThai;
    }

    public TacGia() {
    }

    public String getMaTG() {
        return maTG;
    }

    public void setMaTG(String maTG) {
        this.maTG = maTG;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return maTG + "," + hoTen + "," + date + "," + queQuan + "," + trangThai;
    }
    
    
}
