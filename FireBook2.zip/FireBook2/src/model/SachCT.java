/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author admin
 */
public class SachCT {
    String maSachCT;
    String maTheLoai;
    String maSach;
    String maTacGia;
    int namTaiBan;
    int soTrang;
    int soTap;

    public SachCT() {
    }

    public SachCT(String maSachCT, String maTheLoai, String maSach, String maTacGia, int namTaiBan, int soTrang, int soTap) {
        this.maSachCT = maSachCT;
        this.maTheLoai = maTheLoai;
        this.maSach = maSach;
        this.maTacGia = maTacGia;
        this.namTaiBan = namTaiBan;
        this.soTrang = soTrang;
        this.soTap = soTap;
    }

    public String getMaSachCT() {
        return maSachCT;
    }

    public void setMaSachCT(String maSachCT) {
        this.maSachCT = maSachCT;
    }

    public String getMaTheLoai() {
        return maTheLoai;
    }

    public void setMaTheLoai(String maTheLoai) {
        this.maTheLoai = maTheLoai;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getMaTacGia() {
        return maTacGia;
    }

    public void setMaTacGia(String maTacGia) {
        this.maTacGia = maTacGia;
    }

    public int getNamTaiBan() {
        return namTaiBan;
    }

    public void setNamTaiBan(int namTaiBan) {
        this.namTaiBan = namTaiBan;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public int getSoTap() {
        return soTap;
    }

    public void setSoTap(int soTap) {
        this.soTap = soTap;
    }

    @Override
    public String toString() {
        return maSachCT + "," + maTheLoai + "," + maSach + "," + maTacGia + "," + namTaiBan + "," + soTrang + "," + soTap;
    }
    
    
}
