/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.*;
import java.util.ArrayList;
import model.KhachHang;
import untility.DBConText;

public class Khachhangservice {

    public ArrayList GetAllData() {
        ArrayList<KhachHang> kh = new ArrayList<>();
        String Sql = "select * from KhachHang";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(Sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                KhachHang s = new KhachHang();
                s.setMaKH(rs.getString("MaKhachHang"));
                s.setHoTen(rs.getString("HoTen"));
                s.setEmail(rs.getString("Email"));
                s.setSDT(rs.getString("SDT"));
                s.setDiaChi(rs.getString("DiaChi"));
                s.setNgaySinh(rs.getString("NgaySinh"));
                s.setGioiTinh(rs.getBoolean("GioiTinh"));
                s.setTrangThai(rs.getBoolean("TrangThai"));
                kh.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return kh;
    }

    public Integer ADD(KhachHang kh) {
        Integer row = null;
        String sql = "INSERT INTO KhachHang (MaKhachHang, HoTen, Email, SDT, DiaChi, NgaySinh, GioiTinh, TrangThai)\n"
                + "VALUES(?,?,?,?,?,?,?,?)";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kh.getMaKH());
            pstm.setString(2, kh.getHoTen());
            pstm.setString(3, kh.getEmail());
            pstm.setString(4, kh.getSDT());
            pstm.setString(5, kh.getDiaChi());
            pstm.setString(6, kh.getNgaySinh());
            pstm.setBoolean(7, kh.isGioiTinh());
            pstm.setBoolean(8, kh.isTrangThai());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }

    public Integer Delete(KhachHang kh) {
        Integer row = null;
        String sql = "DELETE FROM KhachHang\n"
                + "WHERE MaKhachHang = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kh.getMaKH());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }

    public Integer Update(KhachHang kh) {
        Integer row = null;
        String sql = "UPDATE KhachHang SET\n"

                + "HoTen = ?,\n"
                + "Email = ?,\n"
                + "SDT = ?,\n"
                + "DiaChi= ?,\n"
                + "NgaySinh= ?,\n"
                + "GioiTinh = ?,\n"
                + "TrangThai = ?\n"
                + "WHERE MaKhachHang = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(8, kh.getMaKH());
            pstm.setString(1, kh.getHoTen());
            pstm.setString(2, kh.getEmail());
            pstm.setString(3, kh.getSDT());
            pstm.setString(4, kh.getDiaChi());
            pstm.setString(5, kh.getNgaySinh());
            pstm.setBoolean(6, kh.isGioiTinh());
            pstm.setBoolean(7, kh.isTrangThai());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
    public KhachHang GetTimKiem(String maKhachHang) {
        String Sql = "select * from KhachHang where MaKhachHang = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(Sql);
            pstm.setString(1, maKhachHang);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                KhachHang s = new KhachHang();
                s.setMaKH(rs.getString("MaKhachHang"));
                s.setHoTen(rs.getString("HoTen"));
                s.setEmail(rs.getString("Email"));
                s.setSDT(rs.getString("SDT"));
                s.setDiaChi(rs.getString("DiaChi"));
                s.setNgaySinh(rs.getString("NgaySinh"));
                s.setGioiTinh(rs.getBoolean("GioiTinh"));
                s.setTrangThai(rs.getBoolean("TrangThai"));
                return s;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
