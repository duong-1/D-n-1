/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.TacGia;
import untility.DBConText;

/**
 *
 * @author ACER
 */
public class Tacgiaservice {
    public ArrayList<TacGia> getAllData(){
        ArrayList<TacGia> list= new ArrayList<>();
        list.clear();
        String sql="SELECT MaTacGia, HoTen, NgaySinh, QueQuan, TrangThai FROM TacGia";
        Connection con= DBConText.getConnection();
        try {
            PreparedStatement pstm= con.prepareStatement(sql);
            ResultSet rs= pstm.executeQuery();
            while (rs.next()) {                
                TacGia nv= new TacGia();
                nv.setMaTG(rs.getString("MaTacGia"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setDate(rs.getString("NgaySinh"));
                nv.setQueQuan(rs.getString("QueQuan"));
                nv.setTrangThai(rs.getString("TrangThai").equals("Hoạt Động")?true:false);
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public boolean InsertData(TacGia nv){
        String sql="INSERT INTO TacGia (MaTacGia, HoTen, NgaySinh, QueQuan, TrangThai)\n" +
"VALUES (?,?,?,?,?)";
        Connection con= DBConText.getConnection();
        try {
            PreparedStatement pstm= con.prepareStatement(sql);
            pstm.setObject(1, nv.getMaTG());
            pstm.setObject(2, nv.getHoTen());
            pstm.setObject(3, nv.getDate());
            pstm.setObject(4, nv.getQueQuan());
            pstm.setObject(5, nv.isTrangThai());
            return pstm.executeUpdate()>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean DeleteData(TacGia nv){
        String sql="Delete from TacGia where MaTacGia=?";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm=con.prepareStatement(sql);
            pstm.setObject(1, nv.getMaTG());
            return pstm.executeUpdate()>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public Integer Update(TacGia kh) {
        Integer row = null;
        String sql = "UPDATE TheLoai SET\n"

                + "HoTen = ?,\n"
                + "NgaySinh = ?\n"
                + "QueQuan = ?\n"
                + "TrangThai = ?\n"
                + "WHERE MaTacGia = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(5, kh.getMaTG());
            pstm.setString(1, kh.getHoTen());
            pstm.setString(2, kh.getDate());
            pstm.setString(3, kh.getQueQuan());
            pstm.setBoolean(4, kh.isTrangThai());

            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
}
