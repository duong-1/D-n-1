/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Sach;
import untility.DBConText;
/**
 *
 * @author ACER
 */
public class Sachservice {
    public ArrayList<Sach> getAllData() {
    ArrayList<Sach> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaSach, MaNhaXuatBan, TenSach, GiaBan, MoTa, SoLuong, TrangThai FROM Sach";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            Sach sach = new Sach();
            sach.setMaSach(rs.getString("MaSach"));
            sach.setMaNXB(rs.getString("MaNhaXuatBan"));
            sach.setTenSach(rs.getString("TenSach"));
            sach.setGiaBan(rs.getDouble("GiaBan"));
            sach.setMoTa(rs.getString("MoTa"));
            sach.setSoLuong(rs.getInt("SoLuong"));
            sach.setTrangThai(rs.getBoolean("TrangThai"));
            list.add(sach);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean InsertData(Sach sach) {
    String sql = "INSERT INTO Sach (MaSach, MaNhaXuatBan, TenSach, GiaBan, MoTa, SoLuong, TrangThai)\n" +
                 "VALUES (?, ?, ?, ?, ?, ?, ?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, sach.getMaSach());
        pstm.setString(2, sach.getMaNXB());
        pstm.setString(3, sach.getTenSach());
        pstm.setDouble(4, sach.getGiaBan());
        pstm.setString(5, sach.getMoTa());
        pstm.setInt(6, sach.getSoLuong());
        pstm.setBoolean(7, sach.isTrangThai());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean DeleteData(Sach sach) {
    String sql = "DELETE FROM Sach WHERE MaSach = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, sach.getMaSach());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer Update(Sach sach) {
    Integer row = null;
    String sql = "UPDATE Sach SET\n" +
                 "MaNhaXuatBan = ?,\n" +
                 "TenSach = ?,\n" +
                 "GiaBan = ?,\n" +
                 "MoTa = ?,\n" +
                 "SoLuong = ?,\n" +
                 "TrangThai = ?\n" +
                 "WHERE MaSach = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(7, sach.getMaSach());
        pstm.setString(1, sach.getMaNXB());
        pstm.setString(2, sach.getTenSach());
        pstm.setDouble(3, sach.getGiaBan());
        pstm.setString(4, sach.getMoTa());
        pstm.setInt(5, sach.getSoLuong());
        pstm.setBoolean(6, sach.isTrangThai());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
