/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.HoaDon;
import untility.DBConText;
/**
 *
 * @author ACER
 */
public class HoaDonservice {
    public ArrayList<HoaDon> getAllData() {
    ArrayList<HoaDon> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaHoaDon, MaKhachHang, MaKhuyenMai, MaNhanVien, TenNguoiNhan, GhiChu, SDT, Email, NgayMua, TongTien, TrangThai FROM HoaDon";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            HoaDon hoaDon = new HoaDon();
            hoaDon.setMaHoaDon(rs.getString("MaHoaDon"));
            hoaDon.setMaKhachHang(rs.getString("MaKhachHang"));
            hoaDon.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
            hoaDon.setMaNhanVien(rs.getString("MaNhanVien"));
            hoaDon.setTenNguoiNhan(rs.getString("TenNguoiNhan"));
            hoaDon.setGhiChu(rs.getString("GhiChu"));
            hoaDon.setSDT(rs.getString("SDT"));
            hoaDon.setEmail(rs.getString("Email"));
            hoaDon.setNgayMua(rs.getString("NgayMua"));
            hoaDon.setTongTien(rs.getDouble("TongTien"));
            hoaDon.setTrangThai(rs.getBoolean("TrangThai"));
            list.add(hoaDon);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean InsertData(HoaDon hoaDon) {
    String sql = "INSERT INTO HoaDon (MaHoaDon, MaKhachHang, MaKhuyenMai, MaNhanVien,"
            + " TenNguoiNhan, GhiChu, SDT, Email, NgayMua, TongTien, TrangThai)\n" +
                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, hoaDon.getMaHoaDon());
        pstm.setString(2, hoaDon.getMaKhachHang());
        pstm.setString(3, hoaDon.getMaKhuyenMai());
        pstm.setString(4, hoaDon.getMaNhanVien());
        pstm.setString(5, hoaDon.getTenNguoiNhan());
        pstm.setString(6, hoaDon.getGhiChu());
        pstm.setString(7, hoaDon.getSDT());
        pstm.setString(8, hoaDon.getEmail());
        pstm.setString(9, hoaDon.getNgayMua());
        pstm.setDouble(10, hoaDon.getTongTien());
        pstm.setBoolean(11, hoaDon.isTrangThai());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean DeleteData(HoaDon hoaDon) {
    String sql = "DELETE FROM HoaDon WHERE MaHoaDon = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, hoaDon.getMaHoaDon());
        return pstm.executeUpdate() >0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer Update(HoaDon hoaDon) {
    Integer row = null;
    String sql = "UPDATE HoaDon SET\n" +
                 "MaKhachHang = ?,\n" +
                 "MaKhuyenMai = ?,\n" +
                 "MaNhanVien = ?,\n" +
                 "TenNguoiNhan = ?,\n" +
                 "GhiChu = ?,\n" +
                 "SDT = ?,\n" +
                 "Email = ?,\n" +
                 "NgayMua = ?,\n" +
                 "TongTien = ?,\n" +
                 "TrangThai = ?\n" +
                 "WHERE MaHoaDon = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(11, hoaDon.getMaHoaDon());
        pstm.setString(1, hoaDon.getMaKhachHang());
        pstm.setString(2, hoaDon.getMaKhuyenMai());
        pstm.setString(3, hoaDon.getMaNhanVien());
        pstm.setString(4, hoaDon.getTenNguoiNhan());
        pstm.setString(5, hoaDon.getGhiChu());
        pstm.setString(6, hoaDon.getSDT());
        pstm.setString(7, hoaDon.getEmail());
        pstm.setString(8, hoaDon.getNgayMua());
        pstm.setDouble(9, hoaDon.getTongTien());
        pstm.setBoolean(10, hoaDon.isTrangThai());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
