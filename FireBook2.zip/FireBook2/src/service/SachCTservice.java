/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.SachCT;
import untility.DBConText;
/**
 *
 * @author ACER
 */
public class SachCTservice {
    public ArrayList<SachCT> getAllData() {
    ArrayList<SachCT> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaSachCT, MaTheLoai, MaSach, MaTacGia, NamTaiBan, SoTrang, SoTap FROM SachCT";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            SachCT sachCT = new SachCT();
            sachCT.setMaSachCT(rs.getString("MaSachCT"));
            sachCT.setMaTheLoai(rs.getString("MaTheLoai"));
            sachCT.setMaSach(rs.getString("MaSach"));
            sachCT.setMaTacGia(rs.getString("MaTacGia"));
            sachCT.setNamTaiBan(rs.getInt("NamTaiBan"));
            sachCT.setSoTrang(rs.getInt("SoTrang"));
            sachCT.setSoTap(rs.getInt("SoTap"));
            list.add(sachCT);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean InsertData(SachCT sachCT) {
    String sql = "INSERT INTO SachCT (MaSachCT, MaTheLoai, MaSach, MaTacGia, NamTaiBan, SoTrang, SoTap)\n" +
                 "VALUES (?, ?, ?, ?, ?, ?, ?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, sachCT.getMaSachCT());
        pstm.setString(2, sachCT.getMaTheLoai());
        pstm.setString(3, sachCT.getMaSach());
        pstm.setString(4, sachCT.getMaTacGia());
        pstm.setInt(5, sachCT.getNamTaiBan());
        pstm.setInt(6, sachCT.getSoTrang());
        pstm.setInt(7, sachCT.getSoTap());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean DeleteData(SachCT sachCT) {
    String sql = "DELETE FROM SachCT WHERE MaSachCT = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, sachCT.getMaSachCT());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer Update(SachCT sachCT) {
    Integer row = null;
    String sql = "UPDATE SachCT SET\n" +
                 "MaTheLoai = ?,\n" +
                 "MaSach = ?,\n" +
                 "MaTacGia = ?,\n" +
                 "NamTaiBan = ?,\n" +
                 "SoTrang = ?,\n" +
                 "SoTap = ?\n" +
                 "WHERE MaSachCT = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(7, sachCT.getMaSachCT());
        pstm.setString(1, sachCT.getMaTheLoai());
        pstm.setString(2, sachCT.getMaSach());
        pstm.setString(3, sachCT.getMaTacGia());
        pstm.setInt(4, sachCT.getNamTaiBan());
        pstm.setInt(5, sachCT.getSoTrang());
        pstm.setInt(6, sachCT.getSoTap());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
