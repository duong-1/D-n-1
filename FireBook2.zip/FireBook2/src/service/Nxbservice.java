/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.NXB;
import untility.DBConText;

/**
 *
 * @author ACER
 */
public class Nxbservice {
    public ArrayList<NXB> getAllDataNhaXuatBan() {
    ArrayList<NXB> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaNhaXuatBan, TenNhaXuatBan, DiaChi FROM NhaXuatBan";
        Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            NXB nxb = new NXB();
            nxb.setMaNXB(rs.getString("MaNhaXuatBan"));
            nxb.setTenNXB(rs.getString("TenNhaXuatBan"));
            nxb.setDiaChi(rs.getString("DiaChi"));
            list.add(nxb);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean insertDataNhaXuatBan(NXB nxb) {
    String sql = "INSERT INTO NhaXuatBan (MaNhaXuatBan, TenNhaXuatBan, DiaChi)\n" +
                 "VALUES (?,?,?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setObject(1, nxb.getMaNXB());
        pstm.setObject(2, nxb.getTenNXB());
        pstm.setObject(3, nxb.getDiaChi());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean deleteDataNhaXuatBan(NXB nxb) {
    String sql = "DELETE FROM NhaXuatBan WHERE MaNhaXuatBan = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setObject(1, nxb.getMaNXB());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer updateNhaXuatBan(NXB nxb) {
    Integer row = null;
    String sql = "UPDATE NhaXuatBan SET TenNhaXuatBan = ?, DiaChi = ? WHERE MaNhaXuatBan = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(3, nxb.getMaNXB());
        pstm.setString(1, nxb.getTenNXB());
        pstm.setString(2, nxb.getDiaChi());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
