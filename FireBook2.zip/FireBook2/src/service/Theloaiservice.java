/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.TheLoai;
import untility.DBConText;

/**
 *
 * @author ACER
 */
public class Theloaiservice {
    public ArrayList<TheLoai> getAllData(){
        ArrayList<TheLoai> list= new ArrayList<>();
        list.clear();
        String sql="SELECT MaTheLoai, TenTheLoai, TrangThai FROM TheLoai";
        Connection con= DBConText.getConnection();
        try {
            PreparedStatement pstm= con.prepareStatement(sql);
            ResultSet rs= pstm.executeQuery();
            while (rs.next()) {                
                TheLoai nv= new TheLoai();
                nv.setMaTheLoai(rs.getString("MaTheLoai"));
                nv.setTenTheLoai(rs.getString("TenTheLoai"));
                nv.setTrangThai(rs.getString("TrangThai").equals("Còn")?true:false);
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public boolean InsertData(TheLoai nv){
        String sql="INSERT INTO TheLoai (MaTheLoai, TenTheLoai, TrangThai)\n" +
"VALUES (?,?,?)";
        Connection con= DBConText.getConnection();
        try {
            PreparedStatement pstm= con.prepareStatement(sql);
            pstm.setObject(1, nv.getMaTheLoai());
            pstm.setObject(2, nv.getTenTheLoai());
            pstm.setObject(3, nv.isTrangThai());
            return pstm.executeUpdate()>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean DeleteData(TheLoai nv){
        String sql="Delete from TheLoai where MaTheLoai=?";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm=con.prepareStatement(sql);
            pstm.setObject(1, nv.getMaTheLoai());
            return pstm.executeUpdate()>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public Integer Update(TheLoai kh) {
        Integer row = null;
        String sql = "UPDATE TheLoai SET\n"

                + "TenTheLoai = ?,\n"
                + "TrangThai = ?\n"
                + "WHERE MaTheLoai = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(3, kh.getMaTheLoai());
            pstm.setString(1, kh.getTenTheLoai());
            pstm.setBoolean(2, kh.isTrangThai());

            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
}
