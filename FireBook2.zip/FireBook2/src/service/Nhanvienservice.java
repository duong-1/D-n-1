/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.NhanVien;
import untility.DBConText;
/**
 *
 * @author ACER
 */
public class Nhanvienservice {
    public ArrayList<NhanVien> getAllDataNhanVien() {
    ArrayList<NhanVien> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaNhanVien, HoTen, Email, SDT, DiaChi, TrangThai FROM NhanVien";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setMaNhanVien(rs.getString("MaNhanVien"));
            nv.setHoTen(rs.getString("HoTen"));
            nv.setEmail(rs.getString("Email"));
            nv.setSDT(rs.getString("SDT"));
            nv.setDiaChi(rs.getString("DiaChi"));
            nv.setTrangThai(rs.getString("TrangThai").equals("Hoạt Động") ? true : false);
            list.add(nv);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean insertDataNhanVien(NhanVien nv) {
    String sql = "INSERT INTO NhanVien (MaNhanVien, HoTen, Email, SDT, DiaChi, TrangThai)\n" +
                 "VALUES (?,?,?,?,?,?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setObject(1, nv.getMaNhanVien());
        pstm.setObject(2, nv.getHoTen());
        pstm.setObject(3, nv.getEmail());
        pstm.setObject(4, nv.getSDT());
        pstm.setObject(5, nv.getDiaChi());
        pstm.setObject(6, nv.isTrangThai());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean deleteDataNhanVien(NhanVien nv) {
    String sql = "DELETE FROM NhanVien WHERE MaNhanVien = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setObject(1, nv.getMaNhanVien());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer updateNhanVien(NhanVien nv) {
    Integer row = null;
    String sql = "UPDATE NhanVien SET HoTen = ?, Email = ?, SDT = ?, DiaChi = ?, TrangThai = ? WHERE MaNhanVien = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(6, nv.getMaNhanVien());
        pstm.setString(1, nv.getHoTen());
        pstm.setString(2, nv.getEmail());
        pstm.setString(3, nv.getSDT());
        pstm.setString(4, nv.getDiaChi());
        pstm.setBoolean(5, nv.isTrangThai());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
