/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import untility.DBConText;
import java.sql.*;
import java.util.ArrayList;
import model.SanPham;

public class ThanhToanService {
    public ArrayList<SanPham> getAll (){
        ArrayList<SanPham> list = new ArrayList<>();
        list.clear();
        DBConText db = new DBConText();
        Connection conn = db.getConnection();
        String sql = "select ROW_NUMBER() OVER (ORDER BY MaSach) AS STT,  MaSach, TenSach, NamTaiBan, MoTa, GiaNhap, GiaBan, SoLuong from  Sach ";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                SanPham hd = new SanPham();
                hd.setStt(rs.getInt(1));
                hd.setMaSP(rs.getString(2));
                hd.setTenSP(rs.getString(3));
                hd.setNamXB(rs.getString(4));
                hd.setMoTa(rs.getString(5));
                hd.setGiaNhap(rs.getDouble(6));
                hd.setGiaBan(rs.getDouble(7));
                hd.setSoLuongTon(rs.getInt(8));
                list.add(hd);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        return list;
    }
    public void themGH(int soLuong, String maSach){
        DBConText db = new DBConText();
        Connection conn = db.getConnection();
        String sql = "update Sach \n" +
        "set SoLuong = SoLuong - ? where MaSach = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, soLuong);
            ps.setString(2, maSach);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        
        
    }
    public void XoaGH(int soLuong, String maSach){
        DBConText db = new DBConText();
        Connection conn = db.getConnection();
        String sql = "update Sach \n" +
        "set SoLuong = SoLuong + ? where MaSach = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, soLuong);
            ps.setString(2, maSach);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        
        
    }
            
}
