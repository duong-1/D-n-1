/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.HoaDonCT;
import untility.DBConText;
/**
 *
 * @author ACER
 */
public class HoadonCTservice {
    public ArrayList<HoaDonCT> getAllData() {
    ArrayList<HoaDonCT> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaHoaDonCT, MaSachCT, MaHoaDon, SoLuong, GiaBan FROM HoaDonCT";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            HoaDonCT hoaDonCT = new HoaDonCT();
            hoaDonCT.setMaHoaDonCT(rs.getString("MaHoaDonCT"));
            hoaDonCT.setMaSachCT(rs.getString("MaSachCT"));
            hoaDonCT.setMahoaDon(rs.getString("MaHoaDon"));
            hoaDonCT.setSoLuong(rs.getInt("SoLuong"));
            hoaDonCT.setGiaBan(rs.getDouble("GiaBan"));
            list.add(hoaDonCT);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean InsertData(HoaDonCT hoaDonCT) {
    String sql = "INSERT INTO HoaDonCT (MaHoaDonCT, MaSachCT, MaHoaDon, SoLuong, GiaBan)\n" +
                 "VALUES (?, ?, ?, ?, ?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, hoaDonCT.getMaHoaDonCT());
        pstm.setString(2, hoaDonCT.getMaSachCT());
        pstm.setString(3, hoaDonCT.getMahoaDon());
        pstm.setInt(4, hoaDonCT.getSoLuong());
        pstm.setDouble(5, hoaDonCT.getGiaBan());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean DeleteData(HoaDonCT hoaDonCT) {
    String sql = "DELETE FROM HoaDonCT WHERE MaHoaDonCT = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, hoaDonCT.getMaHoaDonCT());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer Update(HoaDonCT hoaDonCT) {
    Integer row = null;
    String sql = "UPDATE HoaDonCT SET\n" +
                 "MaSachCT = ?,\n" +
                 "MaHoaDon = ?,\n" +
                 "SoLuong = ?,\n" +
                 "GiaBan = ?\n" +
                 "WHERE MaHoaDonCT = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(5, hoaDonCT.getMaHoaDonCT());
        pstm.setString(1, hoaDonCT.getMaSachCT());
        pstm.setString(2, hoaDonCT.getMahoaDon());
        pstm.setInt(3, hoaDonCT.getSoLuong());
        pstm.setDouble(4, hoaDonCT.getGiaBan());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
