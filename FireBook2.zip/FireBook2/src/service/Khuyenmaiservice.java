/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.KhuyenMai;
import untility.DBConText;
/**
 *
 * @author ACER
 */
public class Khuyenmaiservice {
    public ArrayList<KhuyenMai> getAllData() {
    ArrayList<KhuyenMai> list = new ArrayList<>();
    list.clear();
    String sql = "SELECT MaKhuyenMai, TenKhuyenMai, NgayBatDau, NgayKetThuc, DieuKien, TrangThai FROM KhuyenMai";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            KhuyenMai km = new KhuyenMai();
            km.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
            km.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
            km.setNgayBatDau(rs.getString("NgayBatDau"));
            km.setNgayKetThuc(rs.getString("NgayKetThuc"));
            km.setDieuKien(rs.getString("DieuKien"));
            km.setTrangThai(rs.getBoolean("TrangThai"));
            list.add(km);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

public boolean InsertData(KhuyenMai km) {
    String sql = "INSERT INTO KhuyenMai (MaKhuyenMai, TenKhuyenMai, NgayBatDau, NgayKetThuc, DieuKien, TrangThai)\n" +
                 "VALUES (?, ?, ?, ?, ?, ?)";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, km.getMaKhuyenMai());
        pstm.setString(2, km.getTenKhuyenMai());
        pstm.setString(3, km.getNgayBatDau());
        pstm.setString(4, km.getNgayKetThuc());
        pstm.setString(5, km.getDieuKien());
        pstm.setBoolean(6, km.isTrangThai());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public boolean DeleteData(KhuyenMai km) {
    String sql = "DELETE FROM KhuyenMai WHERE MaKhuyenMai = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, km.getMaKhuyenMai());
        return pstm.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

public Integer Update(KhuyenMai km) {
    Integer row = null;
    String sql = "UPDATE KhuyenMai SET\n" +
                 "TenKhuyenMai = ?,\n" +
                 "NgayBatDau = ?,\n" +
                 "NgayKetThuc = ?,\n" +
                 "DieuKien = ?,\n" +
                 "TrangThai = ?\n" +
                 "WHERE MaKhuyenMai = ?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(6, km.getMaKhuyenMai());
        pstm.setString(1, km.getTenKhuyenMai());
        pstm.setString(2, km.getNgayBatDau());
        pstm.setString(3, km.getNgayKetThuc());
        pstm.setString(4, km.getDieuKien());
        pstm.setBoolean(5, km.isTrangThai());
        row = pstm.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return row;
}
}
