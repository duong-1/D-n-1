/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Sach {
    String maSach;
    String tenSach;
    int maNhaXuatBan;
    Boolean trangThai;
 


    public Sach() {
    }

    public Sach(String maSach, String tenSach, int maNhaXuatBan, Boolean trangThai) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.maNhaXuatBan = maNhaXuatBan;
        this.trangThai = trangThai;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public int getMaNhaXuatBan() {
        return maNhaXuatBan;
    }

    public void setMaNhaXuatBan(int maNhaXuatBan) {
        this.maNhaXuatBan = maNhaXuatBan;
    }

    public Boolean getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Boolean trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return maSach + "," + tenSach + "," + maNhaXuatBan + "," + trangThai;
    }

    

    

    
    
    
}
