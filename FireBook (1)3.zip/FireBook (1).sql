﻿create database firebook
go
use firebook
GO

create table KhachHang(
	MaKhachHang varchar(20) primary key,
	HoTen nvarchar(100),
	Email nvarchar(100),
	SDT varchar(15),
	DiaChi nvarchar(200),
	NgaySinh date,
	GioiTinh bit,
	TrangThai bit
)

CREATE TABLE TacGia (
    MaTacGia INT IDENTITY(1,1) PRIMARY KEY,
    HoTen nvarchar(100),
    NgaySinh date,
    QueQuan nvarchar(200),
    TrangThai bit
)

CREATE TABLE TheLoai (
    MaTheLoai INT IDENTITY(1,1) PRIMARY KEY,
    TenTheLoai nvarchar(100),
    TrangThai bit
)

CREATE TABLE NhaXuatBan (
    MaNhaXuatBan INT IDENTITY(1,1) PRIMARY KEY, 
    TenNhaXuatBan nvarchar(100),
)

create table NhanVien(
	MaNhanVien varchar(20) primary key,
	HoTen nvarchar(100),
	Email varchar(100),
	SDT varchar(20),
	DiaChi nvarchar(200),
	TrangThai bit
)

create table KhuyenMai(
	MaKhuyenMai varchar(20) primary key,
	TenKhuyenMai nvarchar(100),
	NgayBatDau date,
	NgayKetThuc date,
	DieuKien varchar(1000),
	TrangThai bit
)

create table Sach(
	MaSach varchar(20) primary key,
	MaNhaXuatBan int foreign key references NhaXuatBan(MaNhaXuatBan),
	TenSach nvarchar(100),
	TrangThai bit
)


create table HoaDon(
	MaHoaDon varchar(20) primary key,
	MaKhachHang varchar(20) foreign key references KhachHang(MaKhachHang),
	MaKhuyenMai varchar(20) foreign key references KhuyenMai(MaKhuyenMai),
	MaNhanVien varchar(20) foreign key references NhanVien(MaNhanVien),
	TenNguoiNhan nvarchar(100),
	GhiChu nvarchar(200),
	SDT varchar (20),
	Email varchar(50),
	NgayMua date,
	TongTien money,
	TrangThai bit
)
CREATE TABLE SachCT (
    MaSachCT INT IDENTITY(1,1) PRIMARY KEY,
    MaTheLoai INT FOREIGN KEY REFERENCES TheLoai(MaTheLoai),
    MaSach varchar(20) FOREIGN KEY REFERENCES Sach(MaSach),
    MaTacGia INT FOREIGN KEY REFERENCES TacGia(MaTacGia),
	GiaBan money,
	MoTa nvarchar(200),
	SoLuong int,
	NamXuatban int,
	NamTaiBan int,
	SoTrang int,
	SoTap int,
	TrangThai bit,
	TenSachCT nvarchar(100)
)

CREATE TABLE HoaDonCT (
    MaHoaDonCT INT IDENTITY(1,1) PRIMARY KEY,
    MaSachCT INT FOREIGN KEY REFERENCES SachCT(MaSachCT),
    MaHoaDon varchar(20) FOREIGN KEY REFERENCES HoaDon(MaHoaDon),
	MaSach varchar(20) FOREIGN KEY REFERENCES Sach(MaSach),
    SoLuong int,
    GiaBan money
)


SELECT * FROM KhachHang;
SELECT * FROM TacGia;
SELECT * FROM TheLoai;
SELECT * FROM NhaXuatBan;
SELECT * FROM NhanVien;
SELECT * FROM KhuyenMai;
SELECT * FROM Sach;
SELECT * FROM HoaDon;
SELECT * FROM SachCT;
SELECT * FROM HoaDonCT;



INSERT INTO KhachHang (MaKhachHang, HoTen, Email, SDT, DiaChi, NgaySinh, GioiTinh, TrangThai)
VALUES ('KH001', 'Nguyen Van A', 'a@gmail.com', '0123456789', '123 Street, City', '1990-01-01', 1, 1),
       ('KH002', 'Tran Thi B', 'b@gmail.com', '0987654321', '456 Street, City', '1995-05-15', 0, 1);


INSERT INTO TacGia (HoTen, NgaySinh, QueQuan, TrangThai)
VALUES ('Author A', '1980-02-20', 'City A', 1),
       ('Author B', '1975-08-10', 'City B', 1);


INSERT INTO TheLoai (TenTheLoai, TrangThai)
VALUES ('Category A', 1),
       ('Category B', 1);


INSERT INTO NhaXuatBan (TenNhaXuatBan)
VALUES ('Publisher A'),
       ('Publisher B');


INSERT INTO NhanVien (MaNhanVien, HoTen, Email, SDT, DiaChi, TrangThai)
VALUES ('NV001', 'Staff A', 'staffA@gmail.com', '0123456789', '789 Street, City', 1),
       ('NV002', 'Staff B', 'staffB@gmail.com', '0987654321', '987 Street, City', 1);


INSERT INTO KhuyenMai (MaKhuyenMai, TenKhuyenMai, NgayBatDau, NgayKetThuc, DieuKien, TrangThai)
VALUES ('KM001', 'Sale 20%', '2023-01-01', '2023-01-31', 'Order >= 3 books', 1),
       ('KM002', 'Sale 30%', '2023-02-01', '2023-02-28', 'Order >= 5 books', 1);


INSERT INTO Sach (MaSach, MaNhaXuatBan, TenSach, TrangThai)
VALUES ('S001', 1, 'Book A', 1),
       ('S002', 2, 'Book B', 1);


INSERT INTO HoaDon (MaHoaDon, MaKhachHang, MaKhuyenMai, MaNhanVien, TenNguoiNhan, GhiChu, SDT, Email, NgayMua, TongTien, TrangThai)
VALUES ('HD001', 'KH001', 'KM001', 'NV001', 'Customer A', 'Note A', '0123456789', 'customerA@gmail.com', '2023-01-15', 500000, 1),
       ('HD002', 'KH002', 'KM002', 'NV002', 'Customer B', 'Note B', '0987654321', 'customerB@gmail.com', '2023-02-20', 700000, 1);


INSERT INTO SachCT (MaTheLoai, MaSach, MaTacGia, GiaBan, MoTa, SoLuong, NamXuatban, NamTaiBan, SoTrang, SoTap, TrangThai, TenSachCT)
VALUES (1, 'S001', 1, 150000, 'Description A', 50, 2020, 2021, 200, 2, 1, 'Book A - Edition 1'),
       (2, 'S002', 2, 200000, 'Description B', 30, 2018, 2019, 150, 1, 1, 'Book B - Edition 1');


INSERT INTO HoaDonCT (MaSachCT, MaHoaDon, MaSach, SoLuong, GiaBan)
VALUES (1, 'HD001', 'S001', 2, 150000),
       (2, 'HD001', 'S002', 3, 200000),
       (2, 'HD002', 'S002', 1, 200000);


SELECT
    Sach.MaSach,
    SachCT.TenSachCT,
    SachCT.GiaBan,
    SachCT.MoTa,
    SachCT.SoLuong,
    SachCT.TrangThai AS SachTrangThai,
    SachCT.NamXuatBan,
    SachCT.NamTaiBan,
    SachCT.SoTrang,
    SachCT.SoTap,
    TheLoai.TenTheLoai,
    NhaXuatBan.TenNhaXuatBan,
    TacGia.HoTen AS TenTacGia,
    TheLoai.MaTheLoai,
    NhaXuatBan.MaNhaXuatBan,
    TacGia.MaTacGia
FROM Sach
JOIN SachCT ON Sach.MaSach = SachCT.MaSach
JOIN TheLoai ON SachCT.MaTheLoai = TheLoai.MaTheLoai
JOIN NhaXuatBan ON Sach.MaNhaXuatBan = NhaXuatBan.MaNhaXuatBan
JOIN TacGia ON SachCT.MaTacGia = TacGia.MaTacGia
WHERE Sach.MaSach = 'S001'


	 



