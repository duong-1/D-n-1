/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author admin
 */
public class Sach {
    String maSach;
    String tenSach;
    double giaBan;
    int soLuong;
    boolean trangThai;
    int namTaiBan;
    int soTrang;
    int soTap;

    public Sach() {
    }

    public Sach(String maSach, String tenSach, double giaBan, int soLuong, boolean trangThai, int namTaiBan, int soTrang, int soTap) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.giaBan = giaBan;
        this.soLuong = soLuong;
        this.trangThai = trangThai;
        this.namTaiBan = namTaiBan;
        this.soTrang = soTrang;
        this.soTap = soTap;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    public int getNamTaiBan() {
        return namTaiBan;
    }

    public void setNamTaiBan(int namTaiBan) {
        this.namTaiBan = namTaiBan;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public int getSoTap() {
        return soTap;
    }

    public void setSoTap(int soTap) {
        this.soTap = soTap;
    }

    @Override
    public String toString() {
        return maSach + "," + tenSach + "," + giaBan + "," + soLuong + "," + trangThai + "," + namTaiBan + "," + soTrang + "," + soTap;
    }
    
    
}
