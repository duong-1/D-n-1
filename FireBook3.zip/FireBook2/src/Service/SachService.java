/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import Model.Sach; 
import untility.DBConText;
/**
 *
 * @author admin
 */
public class SachService {
    public ArrayList<Sach> getAllData(){
        ArrayList<Sach> list = new ArrayList<>();
        list.clear();
        String sql = "SELECT MaSach, TenSach, GiaBan, SoLuong, TrangThai, NamTaiBan, SoTrang, SoTap FROM Sach";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {                
                Sach sach = new Sach();
                sach.setMaSach(rs.getString("MaSach"));
                sach.setTenSach(rs.getString("TenSach"));
                sach.setGiaBan(rs.getDouble("GiaBan"));
                sach.setSoLuong(rs.getInt("SoLuong"));
                sach.setTrangThai(rs.getBoolean("TrangThai"));
                sach.setNamTaiBan(rs.getInt("NamTaiBan"));
                sach.setSoTrang(rs.getInt("SoTrang"));
                sach.setSoTap(rs.getInt("SoTap"));
                list.add(sach);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public boolean insertData(Sach sach){
        String sql = "INSERT INTO Sach (MaSach, TenSach, GiaBan, SoLuong, TrangThai, NamTaiBan, SoTrang, SoTap)\n" +
                     "VALUES (?,?,?,?,?,?,?,?)";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setObject(1, sach.getMaSach());
            pstm.setObject(2, sach.getTenSach());
            pstm.setObject(3, sach.getGiaBan());
            pstm.setObject(4, sach.getSoLuong());
            pstm.setObject(5, sach.isTrangThai());
            pstm.setObject(6, sach.getNamTaiBan());
            pstm.setObject(7, sach.getSoTrang());
            pstm.setObject(8, sach.getSoTap());
            return pstm.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteData(Sach sach){
        String sql = "DELETE FROM Sach WHERE MaSach=?";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setObject(1, sach.getMaSach());
            return pstm.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Integer update(Sach sach) {
        Integer row = null;
        String sql = "UPDATE Sach SET\n"
                
                + "TenSach = ?,\n"
                + "GiaBan = ?,\n"
              
                + "SoLuong = ?,\n"
                + "TrangThai = ?,\n"
                + "NamTaiBan = ?,\n"
                + "SoTrang = ?,\n"
                + "SoTap = ?\n"
                + "WHERE MaSach = ?";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setObject(8, sach.getMaSach());
            pstm.setObject(1, sach.getTenSach());
            pstm.setObject(2, sach.getGiaBan());
            pstm.setObject(3, sach.getSoLuong());
            pstm.setObject(4, sach.isTrangThai());
            pstm.setObject(5, sach.getNamTaiBan());
            pstm.setObject(6, sach.getSoTrang());
            pstm.setObject(7, sach.getSoTap());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
    public Sach getSachByMaSach(String maSach) {
    String sql = "SELECT MaSach, TenSach, GiaBan, SoLuong, TrangThai, NamTaiBan, SoTrang, SoTap FROM Sach WHERE MaSach=?";
    Connection con = DBConText.getConnection();
    try {
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, maSach);
        ResultSet rs = pstm.executeQuery();
        if (rs.next()) {
            Sach sach = new Sach();
            sach.setMaSach(rs.getString("MaSach"));
            sach.setTenSach(rs.getString("TenSach"));
            sach.setGiaBan(rs.getDouble("GiaBan"));
            sach.setSoLuong(rs.getInt("SoLuong"));
            sach.setTrangThai(rs.getBoolean("TrangThai"));
            sach.setNamTaiBan(rs.getInt("NamTaiBan"));
            sach.setSoTrang(rs.getInt("SoTrang"));
            sach.setSoTap(rs.getInt("SoTap"));
            return sach;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
   
}
