/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Model.SanPham_1;
import java.util.ArrayList;
import untility.DBConText;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author admin
 */
public class SanPhamService {

    public List<SanPham_1> getAllData(String maSach) {
        List<SanPham_1> result = new ArrayList<>();
        String sql = "SELECT\n"
                + "    Sach.MaSach,\n"
                + "    SachCT.TenSachCT,\n"
                + "    SachCT.GiaBan,\n"
                + "    SachCT.MoTa,\n"
                + "    SachCT.SoLuong,\n"
                + "    SachCT.TrangThai AS SachTrangThai,\n"
                + "    SachCT.NamXuatBan,\n"
                + "    SachCT.NamTaiBan,\n"
                + "    SachCT.SoTrang,\n"
                + "    SachCT.SoTap,\n"
                + "    TheLoai.TenTheLoai,\n"
                + "    NhaXuatBan.TenNhaXuatBan,\n"
                + "    TacGia.HoTen AS TenTacGia,\n"
                + "    TheLoai.MaTheLoai,\n"
                + "    NhaXuatBan.MaNhaXuatBan,\n"
                + "    TacGia.MaTacGia\n"
                + "FROM Sach\n"
                + "JOIN SachCT ON Sach.MaSach = SachCT.MaSach\n"
                + "JOIN TheLoai ON SachCT.MaTheLoai = TheLoai.MaTheLoai\n"
                + "JOIN NhaXuatBan ON Sach.MaNhaXuatBan = NhaXuatBan.MaNhaXuatBan\n"
                + "JOIN TacGia ON SachCT.MaTacGia = TacGia.MaTacGia\n"
                + "WHERE Sach.MaSach = ?";
        Connection con = DBConText.getConnection();
        result.clear();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setObject(1, maSach);
            ResultSet rs = pstm.executeQuery();

            while (rs.next()) {
                SanPham_1 sanPham = new SanPham_1();
                sanPham.setMaSach(rs.getString("MaSach"));
                sanPham.setTenSachCT(rs.getString("TenSachCT"));
                sanPham.setGiaBan(rs.getDouble("GiaBan"));
                sanPham.setMoTa(rs.getString("MoTa"));
                sanPham.setSoLuong(rs.getInt("SoLuong"));
                sanPham.setTrangThai(rs.getBoolean("SachTrangThai"));
                sanPham.setNamXuatBan(rs.getInt("NamXuatBan"));
                sanPham.setNamTaiBan(rs.getInt("NamTaiBan"));
                sanPham.setSoTrang(rs.getInt("SoTrang"));
                sanPham.setSoTap(rs.getInt("SoTap"));
                sanPham.setTenTheLoai(rs.getString("TenTheLoai"));
                sanPham.setTenNXB(rs.getString("TenNhaXuatBan"));
                sanPham.setHoTen(rs.getString("TenTacGia"));
                sanPham.setMaTheLoai(rs.getInt("MaTheLoai"));
                sanPham.setMaNXB(rs.getInt("MaNhaXuatBan"));
                sanPham.setMaTacGia(rs.getInt("MaTacGia"));
                result.add(sanPham);
            }
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean insertData(SanPham_1 sach) {
        String sql = "INSERT INTO TacGia (HoTen, NgaySinh, QueQuan, TrangThai)\n"
                + "VALUES (?,'01/01/2001', 'Address', 1)\n"
                + "\n"
                + "INSERT INTO TheLoai (TenTheLoai, TrangThai)\n"
                + "VALUES (?, 1)\n"
                + "\n"
                + "INSERT INTO SachCT (MaTheLoai, MaSach, MaTacGia, GiaBan, MoTa, SoLuong, TrangThai, NamXuatban, NamTaiBan, SoTrang, SoTap,TenSachCT)\n"
                + "VALUES (SCOPE_IDENTITY(),?,SCOPE_IDENTITY(),?,?,?,?,?,?,?,?,?)";

        try (Connection con = DBConText.getConnection(); PreparedStatement pstm = con.prepareStatement(sql)) {

            pstm.setString(1, sach.getHoTen());
            pstm.setString(2, sach.getTenTheLoai());
            pstm.setString(3, sach.getMaSach());
            pstm.setDouble(4, sach.getGiaBan());
            pstm.setString(5, sach.getMoTa());
            pstm.setInt(6, sach.getSoLuong());
            pstm.setBoolean(7, sach.isTrangThai());
            pstm.setInt(8, sach.getNamXuatBan());
            pstm.setInt(9, sach.getNamTaiBan());
            pstm.setInt(10, sach.getSoTrang());
            pstm.setInt(11, sach.getSoTap());
            pstm.setString(12, sach.getTenSachCT());
            return pstm.executeUpdate() > 0;
        } catch (Exception e) {
            // Handle SQL exceptions
            e.printStackTrace();
        }

        return false;
    }

    public List<String> loadDataFromDatabase() {
        List<String> data = new ArrayList<>();
        String sql = "SELECT TenTheLoai FROM TheLoai";
        //Connection con=DBConText.getConnection();
        try (Connection con = DBConText.getConnection(); PreparedStatement pstm = con.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {

                String value = rs.getString("TenTheLoai");
                data.add(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    public List<String> selectMaNXB() {
        List<String> data = new ArrayList<>();
        String sql = "SELECT MaNhaXuatBan FROM NhaXuatBan";

        try (Connection con = DBConText.getConnection(); PreparedStatement pstm = con.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {

                String value = rs.getString("MaNhaXuatBan");
                data.add(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    public List<String> selectMatacGia() {
        List<String> data = new ArrayList<>();
        String sql = "SELECT MaTacGia FROM TacGia where HoTen =?";

        try (Connection con = DBConText.getConnection(); PreparedStatement pstm = con.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {

                String value = rs.getString("MaTacGia");
                data.add(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    public Integer update(SanPham_1 sach) {
        Integer row = null;
        String sql = "UPDATE SachCT\n"
                + "SET TenSachCT = ?\n"
                + "WHERE SoTap = ?;\n";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setObject(1, sach.getTenSachCT());
            pstm.setObject(2, sach.getSoTap());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }

    public Integer update2(SanPham_1 sach) {
        Integer row = null;
        String sql = "UPDATE TheLoai\n"
                + "SET TenTheLoai = ?\n"
                + "WHERE MaTheLoai = ?;\n"
                + "\n"
                + "UPDATE TacGia\n"
                + "SET HoTen = ?\n"
                + "WHERE MaTacGia = ?;\n"
                + "\n"
                + "UPDATE NhaXuatBan\n"
                + "SET TenNhaXuatBan = ?\n"
                + "WHERE MaNhaXuatBan = ?;\n"
                + "\n"
                + "UPDATE SachCT\n"
                + "SET GiaBan = ?, MoTa = ?, SoLuong = ?, TrangThai = ?, NamXuatban = ?, NamTaiBan = ?, SoTrang = ?, SoTap = ?\n"
                + "WHERE TenSachCT = ?;";
        Connection cn = DBConText.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setObject(15, sach.getTenSachCT());
            pstm.setObject(1, sach.getTenTheLoai());
            pstm.setObject(2, sach.getMaTheLoai());
            pstm.setObject(3, sach.getHoTen());
            pstm.setObject(4, sach.getMaTacGia());
            pstm.setObject(5, sach.getTenNXB());
            pstm.setObject(6, sach.getMaNXB());
            pstm.setObject(7, sach.getGiaBan());
            pstm.setObject(8, sach.getMoTa());
            pstm.setObject(9, sach.getSoLuong());
            pstm.setObject(10, sach.isTrangThai());
            pstm.setObject(11, sach.getNamXuatBan());
            pstm.setObject(12, sach.getNamTaiBan());
            pstm.setObject(13, sach.getSoTrang());
            pstm.setObject(14, sach.getSoTap());
            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }

    public boolean deleteData(SanPham_1 sach) {
        String sql = "DELETE FROM SachCT\n"
                + "WHERE MaSach =?\n"
                + "DELETE FROM TacGia\n"
                + "WHERE HoTen =?\n"
                + "DELETE FROM TheLoai\n"
                + "WHERE TenTheLoai=?";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setObject(1, sach.getMaSach());
            pstm.setObject(2, sach.getHoTen());
            pstm.setObject(3, sach.getTenTheLoai());
            return pstm.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public SanPham_1 getSachByMaSach(String tenSachCT) {
        String sql = "SELECT\n"
                + "    Sach.MaSach,\n"
                + "    SachCT.TenSachCT,\n"
                + "    SachCT.GiaBan,\n"
                + "    SachCT.MoTa,\n"
                + "    SachCT.SoLuong,\n"
                + "    SachCT.TrangThai AS SachTrangThai,\n"
                + "    SachCT.NamXuatBan,\n"
                + "    SachCT.NamTaiBan,\n"
                + "    SachCT.SoTrang,\n"
                + "    SachCT.SoTap,\n"
                + "    TheLoai.TenTheLoai,\n"
                + "    NhaXuatBan.TenNhaXuatBan,\n"
                + "    TacGia.HoTen AS TenTacGia,\n"
                + "    TheLoai.MaTheLoai,\n"
                + "    NhaXuatBan.MaNhaXuatBan,\n"
                + "    TacGia.MaTacGia\n"
                + "FROM Sach\n"
                + "JOIN SachCT ON Sach.MaSach = SachCT.MaSach\n"
                + "JOIN TheLoai ON SachCT.MaTheLoai = TheLoai.MaTheLoai\n"
                + "JOIN NhaXuatBan ON Sach.MaNhaXuatBan = NhaXuatBan.MaNhaXuatBan\n"
                + "JOIN TacGia ON SachCT.MaTacGia = TacGia.MaTacGia\n"
                + "WHERE SachCT.TenSachCT = ?";
        Connection con = DBConText.getConnection();
        try {
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, tenSachCT);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                SanPham_1 sanPham = new SanPham_1();
                sanPham.setMaSach(rs.getString("MaSach"));
                sanPham.setTenSachCT(rs.getString("TenSachCT"));
                sanPham.setGiaBan(rs.getDouble("GiaBan"));
                sanPham.setMoTa(rs.getString("MoTa"));
                sanPham.setSoLuong(rs.getInt("SoLuong"));
                sanPham.setTrangThai(rs.getBoolean("SachTrangThai"));
                sanPham.setNamXuatBan(rs.getInt("NamXuatBan"));
                sanPham.setNamTaiBan(rs.getInt("NamTaiBan"));
                sanPham.setSoTrang(rs.getInt("SoTrang"));
                sanPham.setSoTap(rs.getInt("SoTap"));
                sanPham.setTenTheLoai(rs.getString("TenTheLoai"));
                sanPham.setTenNXB(rs.getString("TenNhaXuatBan"));
                sanPham.setHoTen(rs.getString("TenTacGia"));
                sanPham.setMaTheLoai(rs.getInt("MaTheLoai"));
                sanPham.setMaNXB(rs.getInt("MaNhaXuatBan"));
                sanPham.setMaTacGia(rs.getInt("MaTacGia"));
                return sanPham;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
