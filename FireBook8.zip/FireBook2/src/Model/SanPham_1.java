/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author admin
 */
public class SanPham_1 {
    String maSach;
    String tenSach;
    int MaNXB;
    double giaBan;
    String moTa;
    int soLuong;
    boolean trangThai;
    int namXuatBan;
    int namTaiBan;
    int soTrang;
    int soTap;
    int maTheLoai;
    int maTacGia;
    String tenNXB;
    String tenTheLoai;
    String hoTen;
    String tenSachCT;

    public SanPham_1() {
    }

    public SanPham_1(String maSach, String tenSach, int MaNXB, double giaBan, String moTa, int soLuong, boolean trangThai, int namXuatBan, int namTaiBan, int soTrang, int soTap, int maTheLoai, int maTacGia, String tenNXB, String tenTheLoai, String hoTen, String tenSachCT) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.MaNXB = MaNXB;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.soLuong = soLuong;
        this.trangThai = trangThai;
        this.namXuatBan = namXuatBan;
        this.namTaiBan = namTaiBan;
        this.soTrang = soTrang;
        this.soTap = soTap;
        this.maTheLoai = maTheLoai;
        this.maTacGia = maTacGia;
        this.tenNXB = tenNXB;
        this.tenTheLoai = tenTheLoai;
        this.hoTen = hoTen;
        this.tenSachCT = tenSachCT;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public int getMaNXB() {
        return MaNXB;
    }

    public void setMaNXB(int MaNXB) {
        this.MaNXB = MaNXB;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    public int getNamXuatBan() {
        return namXuatBan;
    }

    public void setNamXuatBan(int namXuatBan) {
        this.namXuatBan = namXuatBan;
    }

    public int getNamTaiBan() {
        return namTaiBan;
    }

    public void setNamTaiBan(int namTaiBan) {
        this.namTaiBan = namTaiBan;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public int getSoTap() {
        return soTap;
    }

    public void setSoTap(int soTap) {
        this.soTap = soTap;
    }

    public int getMaTheLoai() {
        return maTheLoai;
    }

    public void setMaTheLoai(int maTheLoai) {
        this.maTheLoai = maTheLoai;
    }

    public int getMaTacGia() {
        return maTacGia;
    }

    public void setMaTacGia(int maTacGia) {
        this.maTacGia = maTacGia;
    }

    public String getTenNXB() {
        return tenNXB;
    }

    public void setTenNXB(String tenNXB) {
        this.tenNXB = tenNXB;
    }

    public String getTenTheLoai() {
        return tenTheLoai;
    }

    public void setTenTheLoai(String tenTheLoai) {
        this.tenTheLoai = tenTheLoai;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getTenSachCT() {
        return tenSachCT;
    }

    public void setTenSachCT(String tenSachCT) {
        this.tenSachCT = tenSachCT;
    }

    @Override
    public String toString() {
        return maSach + "," + tenSach + "," + MaNXB + "," + giaBan + "," + moTa + "," + soLuong + "," + trangThai + "," + namXuatBan + "," + namTaiBan + "," + soTrang + "," + soTap + "," + maTheLoai + "," + maTacGia + "," + tenNXB + "," + tenTheLoai + "," + hoTen + "," + tenSachCT;
    }

    
    
    
    
}
